import { useState, useRef, useEffect } from "react"
import { Modal, View, Text, StyleSheet, Dimensions, TouchableOpacity, Image } from "react-native"
import * as Progress from 'react-native-progress';
import { IoniconTemplate } from "./navigation/TabBarIcon";

const { width: screenWidth } = Dimensions.get('window');

export const StoryPage = ({ modalVisible, handleCloseModal, stories }: any) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [progress, setProgress] = useState(0);

    const handleNextImage = () => {
        const nextIndex = (currentIndex + 1) % stories.length;
        setCurrentIndex(nextIndex);
        setProgress(0)
    }

    useEffect(() => {
        if (modalVisible) {
            if (progress < 1) {
                const interval = setInterval(() => {
                    setProgress((prev) => prev + 0.1);
                }, 1000);

                return () => clearInterval(interval);
            }

            if (progress > 1) {
                const nextIndex = (currentIndex + 1) % stories.length;
                setCurrentIndex(nextIndex);
                setProgress(0)
            }
        }else{
            setProgress(0);
        }
    }, [progress, modalVisible]);

    useEffect(() => {
        if (modalVisible) {
            setCurrentIndex(0);
        }
    }, [modalVisible])

    return (
        <View>
            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => { }}
            >
                <View style={styles.centeredView}>
                    <View>
                        <Progress.Bar progress={progress} width={screenWidth} height={16} />
                    </View>
                    <TouchableOpacity style={styles.slide} onPress={() => handleNextImage()}>
                        {stories &&
                            <View style={{ position: 'absolute', top: 0, zIndex: 100, left: 0, padding: 10, flexDirection: 'row', gap: 10, justifyContent: 'space-between', width: '100%', backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
                                <View style={{ flexDirection: 'row', gap: 15 }}>
                                    <Image source={{ uri: `http://192.168.50.17:4006/${stories ? stories[currentIndex]?.evidence : ''}` }} style={styles.image_circle} />
                                    <View>
                                        <Text style={{ fontSize: 16, color: 'white' }}>{stories ? stories[currentIndex]?.fullname : ''}</Text>
                                        <View>
                                            <Text style={{ fontSize: 14, fontWeight: 600, color: 'white' }}>{stories ? stories[currentIndex]?.exercise_name : ''}</Text>
                                        </View>
                                    </View>
                                </View>
                                <TouchableOpacity onPress={() => handleCloseModal()}>
                                    <IoniconTemplate name={'close'} color={'white'} size={30} />
                                </TouchableOpacity>
                            </View>
                        }
                        <Image source={{ uri: `http://192.168.50.17:4006/${stories ? stories[currentIndex]?.evidence : ''}` }} style={styles.image} />
                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.4)',
    },
    modalView: {
        margin: 20,
        backgroundColor: 'white',
        borderRadius: 10,
        padding: 35,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    slide: {
        width: screenWidth,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    image: {
        width: '100%',
        height: '100%',
        resizeMode: 'cover',
    },
    image_circle: {
        width: 40,
        height: 40,
        resizeMode: 'cover',
        borderRadius: 100
    },
    title: {
        position: 'absolute',
        bottom: 60,
        color: '#fff',
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    description: {
        position: 'absolute',
        bottom: 20,
        color: '#fff',
        fontSize: 16,
        textAlign: 'center',
    },
})