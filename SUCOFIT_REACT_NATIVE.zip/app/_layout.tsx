import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect, useState, createContext } from 'react';
import 'react-native-reanimated';
import ToastManager from 'toastify-react-native'
import { Text, PermissionsAndroid, Alert } from 'react-native';
import * as TaskManager from 'expo-task-manager';
import * as BackgroundFetch from 'expo-background-fetch';
import { Pedometer } from 'expo-sensors';

import { useColorScheme } from '@/hooks/useColorScheme';
const PEDOMETER_TASK = 'background-pedometer-task';
export const MyContext: any = createContext(null);

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [isPedometerAvailable, setIsPedometerAvailable] = useState('checking');
  const [currentStepCount, setCurrentStepCount] = useState(0);

  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
    PoppinsLight: require('../assets/fonts/Poppins-Light.ttf'),
    PoppinsRegular: require('../assets/fonts/Poppins-Regular.ttf'),
    PoppinsMedium: require('../assets/fonts/Poppins-Medium.ttf'),
    PoppinsSemiBold: require('../assets/fonts/Poppins-SemiBold.ttf'),
    PoppinsBold: require('../assets/fonts/Poppins-Bold.ttf'),
  });

  const subscribe = async () => {
    const isAvailable = await Pedometer.isAvailableAsync();
    setIsPedometerAvailable(String(isAvailable));

    if (isAvailable) {
      const end = new Date();
      const start = new Date();
      start.setDate(end.getDate() - 1);

      return Pedometer.watchStepCount(result => {
        setCurrentStepCount(result.steps);
      });
    }
  };

  const requestActivityPermission = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACTIVITY_RECOGNITION,
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log("Go");
      } else {
        console.log("No");
        
      }
    } catch (err) {
      console.warn(err);
    }
  };

  useEffect(() => {
    requestActivityPermission();
    const subscription: any = subscribe();
    return () => {
      if(subscription){
        subscription?.remove()
      }
    };
  }, []);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return (
    <MyContext.Provider value={{ currentStepCount, setCurrentStepCount }}>
      <ThemeProvider value={DefaultTheme}> 
        <ToastManager positionValue={20} height={80} width={300} textStyle={{ fontSize: 14,  }}/>
        <Stack>
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} initialParams={{ myData: "Hello from Layout!" }} />
          <Stack.Screen name="+not-found" />
        </Stack>
      </ThemeProvider>
    </MyContext.Provider>
  );
}
