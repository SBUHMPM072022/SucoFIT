import Ionicons from '@expo/vector-icons/Ionicons';
import { StyleSheet, Image, Platform, SafeAreaView, ScrollView, RefreshControl, View, Text, Dimensions } from 'react-native';

import { Collapsible } from '@/components/Collapsible';
import { ExternalLink } from '@/components/ExternalLink';
import ParallaxScrollView from '@/components/ParallaxScrollView';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useCallback, useEffect, useState } from 'react';
import { Auth } from '@/utils/Helper';
import { HeaderPage } from '@/components/HeaderPage';
// import MapView, { Marker, UrlTile } from 'react-native-maps';
import * as Location from 'expo-location';

const { width: screenWidth } = Dimensions.get('window');

export default function TabTwoScreen() {
  const [refreshing, setRefreshing] = useState(false);
  const [location, setLocation]: any = useState({});
  const [errorMsg, setErrorMsg]: any = useState(null);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);


  const getLocation = async () => {
    let { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      setErrorMsg('Permission to access location was denied');
      return;
    }

    let location: any = await Location.getCurrentPositionAsync({});
    setLocation(location.coords);
  }


  useEffect(() => {
    Auth.CheckAuth();
    getLocation();
    
  }, []);


  return (
    // <SafeAreaView style={{ flex: 1 }}>
    //   <HeaderPage headerTitle='Nearest Spots' />
    //   <ScrollView
    //     showsVerticalScrollIndicator={false}
    //     style={{ marginTop: 90, backgroundColor: '#F8F8F8', paddingHorizontal: 15 }}
    //     refreshControl={
    //       <RefreshControl
    //         refreshing={refreshing}
    //         onRefresh={onRefresh}
    //       />
    //     }
    //   >
    //     <View style={{ flexDirection: 'column', paddingVertical: 10 }}>
    //       <Text style={{ fontWeight: 600, marginVertical: 10 }}>Mapping Point</Text>
    //       <MapView
    //         style={styles.map}
    //         initialRegion={{
    //           latitude: -6.2088,
    //           longitude: 106.8456,
    //           latitudeDelta: 0.05,
    //           longitudeDelta: 0.05,
    //         }}
    //       >
    //         <UrlTile
    //           urlTemplate="https://a.tile.openstreetmap.org/{z}/{x}/{y}.png"
    //           maximumZ={19}
    //         />
    //         <Marker
    //           coordinate={{
    //             latitude: location.latitude,
    //             longitude: location.longitude,
    //           }}
    //           title="Lokasi dari Google Maps"
    //           description="Ini adalah koordinat dari Google Maps."
    //         />

    //       </MapView>
    //       <View></View>
    //     </View>
    //   </ScrollView>
    // </SafeAreaView>
    <></>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  map: {
    width: screenWidth,
    height: 300,
  },
  container: {
    flex: 1,
  },
});
